import Vue from 'vue'
import VueStarRating from 'vue-star-rating'
Vue.component('star-rating', VueStarRating);