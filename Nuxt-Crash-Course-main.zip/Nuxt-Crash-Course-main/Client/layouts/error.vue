<template>
    <div class="container">
        <PageNotFound />
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    .container {
        padding: 5rem 0;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 70vh;
    }

</style>